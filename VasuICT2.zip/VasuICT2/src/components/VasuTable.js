import * as React from 'react';
import useMediaQuery from '@mui/material/useMediaQuery/useMediaQuery';
import { useEffect, useState } from 'react';
// import './Table.css'

function Table(props) {
    const matches = useMediaQuery('(max-width:770px)');

    const [tableData, settableData] = useState(props.tableList);
    const [ascending, setascending] = useState(true);
   
    useEffect(() => {
        settableData(props.tableList)
    }, [props.tableList]);
    
    if(matches){
        const lastColOfTable = document.querySelectorAll(".final-score");
        for(let i = 0 ; i < lastColOfTable.length; i++){
            lastColOfTable[i].style.display = 'none';
        }
    }else{
        const lastColOfTable = document.querySelectorAll(".final-score");
        const secondColOfTable = document.querySelectorAll(".rank")
        for(let i = 0 ; i < lastColOfTable.length; i++){
            lastColOfTable[i].style.display = 'table-cell';
        }
        for(let i=0; i< secondColOfTable.length;i++){
            secondColOfTable[i].style.display = "table-cell";
        }
    }
    
    const handleResponsivenessRight = () => {
        const lastColOfTable = document.querySelectorAll(".final-score");
        const secondColOfTable = document.querySelectorAll(".rank")
        for(let i = 0 ; i < lastColOfTable.length; i++){
            lastColOfTable[i].style.display = 'table-cell';
        }
        for(let i=0; i< secondColOfTable.length;i++){
            secondColOfTable[i].style.display = "none";
        }
    }

    const handleResponsivenessLeft = () => {
        const lastColOfTable = document.querySelectorAll(".final-score");
        const secondColOfTable = document.querySelectorAll(".rank")
        for(let i = 0 ; i < lastColOfTable.length; i++){
            lastColOfTable[i].style.display = 'none';
        }
        for(let i=0; i< secondColOfTable.length;i++){
            secondColOfTable[i].style.display = "table-cell";
        }
    }

   
    function sortByname(){
        let data = [...tableData];
        if(ascending){
            data.sort((a, b) => {
                let fa = a.studentName.toLowerCase();
                let fb = b.studentName.toLowerCase();
                return(fa <= fb ? 1 : -1)
            });
            settableData(data);
            setascending(!ascending);
        }
        else{
            data.sort((a, b) => {
                let fa = a.studentName.toLowerCase();
                let fb = b.studentName.toLowerCase();
                return(fa < fb ? -1 : 1)
            });
            settableData(data);
            setascending(!ascending);
        }
    }
    return (
        <div className="table-responsive-md" style={{  height:"508px" }}>
            <button class="btn btn-primary ms-2">

Class Results

</button>
        <table className="table table-hover table-striped border border-dark" style={{fontSize: "13px"}}>
            <thead className="" style={{ borderTop:"5px solid blue",borderBottom:"5px solid orange"}}>
                <tr className=" text-start ">
                    <th style = {{cursor: "pointer"}} id="studentName" className="table-head fw-bold" onClick={() => sortByname(tableData)}> STUDENT <br/>  NAME <span className="studentName-icon ms-2">{ascending ? <i className="fas fa-arrow-up"></i>: <i className="fas fa-arrow-down"></i>}</span></th>
                    <th className=" table-head rank fw-bold">RANK</th>
                    <th className=" table-head fw-bold">PERFORMANCE <br/> LEVEL</th>
                    <th className=" table-head fw-bold">MID 1 SCORE <br/> OUT OF 600</th>
                    <th className=" table-head fw-bold">MID 2 SCORE <br/> OUT OF 600</th>
                    <th className=" table-head final-score fw-bold">FINAL SCORE <br/> OUT OF 600</th>
                    {matches && <th><span className="midscreen-icon ms-1 d-flex justify-content-evenly align-content-center"><i className="fas fa-chevron-left ms-3 tab-left-btn" style={{cursor:"pointer"}} onClick = {handleResponsivenessLeft}></i> <i className="fas fa-chevron-right ms-3 tab-right-btn" style={{cursor:"pointer"}} onClick={handleResponsivenessRight}></i></span></th>}

                </tr>
            </thead>
            <tbody className="table_body">
            {
                tableData.map((stuObj, index) => <tr key={index}>
                    <td>Student {stuObj.studentName.split(" ")[1]}</td>
                    <td className='rank'>{stuObj.rank}</td>
                    <td>
                        {stuObj.completedPercent}
                        {stuObj.peformanceLevel == "Above-Level" && <i className="fas fa-circle ms-1 me-1 text-success"></i>}
                        {stuObj.peformanceLevel == "On-Level" && <i className="fas fa-circle ms-1 me-1 text-warning"></i>}
                        {stuObj.peformanceLevel == "Below-Level" && <i className="fas fa-circle ms-1 me-1 text-danger"></i>}
                        {stuObj.peformanceLevel}
                    </td>
                    <td>{stuObj.mid1Score}</td>
                    <td>{stuObj.mid2score}</td>
                    <td className='final-score'>{stuObj.finalscore}</td>
                    {matches && <td><span></span></td>}
                </tr>)
            }
            </tbody>
        </table>
      </div> 
    );
}

export default Table;