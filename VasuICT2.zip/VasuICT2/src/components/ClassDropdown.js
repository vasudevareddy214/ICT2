import React from 'react';

function ClassDropdown(props) {


    return (
        <>
        {props.list.length && <div>
            {props.state == "class" ?  <select className="form-select class-list mb-sm-5" id="class" onChange={props.resetPerformanceDropDown}>
            {
                props.list.map((element, index)=>
                    <option value={element.split(" ")[1]} key = {index}>{element}</option>
                )
            }
        </select> : <select className="form-select performance-list mb-sm-5" id="class">
        <option value="select">Select Level</option>
            {
                props.list.map((element, index)=>
                    <option value={element} key = {index}>{element}</option>
                )
            }
        </select>}
        </div> }
            
        </>
    );
}

export default ClassDropdown;