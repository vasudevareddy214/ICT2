import './App.css';
import ClassDropdown from './components/ClassDropdown';
import { useState, useEffect } from 'react';
import Table from './components/VasuTable';
function App() {
  const [classList, setclassList] = useState([]);
    const [performanceList, setperformanceList] = useState([]);
    const [classes, setclasses] = useState([]);
    const [filterStudents, setfilterStudents] = useState([]);


    const fetchDropdownApi = async (url)=>{
        try{
            let res = await fetch(url);
            let data = await res.json();
            let classDropdown = data.classDropdown;
            classDropdown.sort((a, b) => a.toLowerCase() >= b.toLowerCase() ? 1 : -1)
            setclassList([...classDropdown])
            let performanceLevel = data.performanceLevel;
            setperformanceList([...performanceLevel])
        }
        catch(err){
            console.log(err);
        }
        
    }

    
    //fetching classes data
    const fetchClasses= async (url)=>{
      try{
        let res = await fetch(url);
        let data = await res.json();
        setclasses([...data.classes]);
      }
      catch(err){
          console.log(err);
      }
    }

    useEffect(() => {
      fetchDropdownApi("https://jsonblob.com/api/jsonBlob/922837073522868224");
      fetchClasses("https://jsonblob.com/api/jsonBlob/922847334786940928", () => console.log("success"));
    }, []);
    useEffect(() => {
      getReportDetails()

    }, [classes]);

    let classValue = document.querySelector(".class-list");
    let performanceValue = document.querySelector(".performance-list");

    const getReportDetails = () => {
      if(classList.length != 0 ){
        let selectedClass = classes.filter((ele) => ele.className == classValue.value);
        if(selectedClass.length != 0){
            let filteredStudents = selectedClass[0].studentresults.filter((studentObj) => studentObj.peformanceLevel == performanceValue.value);
            if(filteredStudents.length != 0){
              setfilterStudents([...filteredStudents]);
            }else{
              setfilterStudents([...selectedClass[0].studentresults]);
            }
        }
      }
    }
    const resetPerformanceDropDown = ()=>{
      document.querySelector(".performance-list").value = "select"
    }
  return (
    <div className="container">
      <h1 className="fw-bold text-center mt-5">
        Student Progress Report
      </h1>
      <div className="row mt-5 mx-auto">
        <div className="mt-1 col-6 col-sm-4 d-block mx-auto drop-down">
            <label htmlFor="class" className=""><h6 className="fw-bold">ClassName: </h6></label>
            <ClassDropdown list ={classList} state={"class"} resetPerformanceDropDown={resetPerformanceDropDown}/>
               
        </div>
        <div className="mt-1 col-6 col-sm-4 d-block mx-auto drop-down">
          <label htmlFor="" className=""><h6 className="fw-bold">Performance Level: </h6></label>
          <ClassDropdown list ={performanceList} state={"level"}/>  
        </div>
        <div className="mt-2 mb-3 col-4 col-sm-2 d-block mx-auto">
            <button className="btn btn-primary mt-4 d-block mx-auto getReportBtn form-control" onClick={getReportDetails}>Get Report</button>
        </div>
      </div>

      <Table tableList = {filterStudents} />

    </div>
  );
}

export default App;
